import express from "express"
import cors from "cors"
import cookieParser from "cookie-parser"

const app=express()
//configuration of server
app.use(cors(
    {
        origin:process.env.CORS_ORIGIN,
        credentials:true
    }
))
app.use(express.json({
    limit:"15kb"
}))//used to get data from forms in json format
app.use(express.urlencoded({extended:true,limit:"15kb"}))//used to get data from urls
app.use(express.static("public"))//used to store pdf's or other sorts of data in server
app.use(cookieParser())

//import routes
import userRouter from "./routes/user.routes.js"
app.use("api/v1/user",userRouter)

export {app}