import dotenv from "dotenv"
import mongoose from "mongoose"
import express from "express"
import {DB_NAME} from "./constant.js"
import connectDB from "./db/index.js"
import {app} from "./app.js"

dotenv.config({path: "./env"})


connectDB()
.then( () =>{
    app.listen(process.env.PORT,() =>{
        console.log("server is running.....")
    })
})
.catch((error) =>{
    console.log("MONGOdb connection failed ERROR:",error)
})



/*
const app=express();
;(async () =>{
    try{
       await mongoose.connect(`${process.env.MONGODB_URL}/${DB_NAME}`)

       app.listen(process.env.PORT,() =>{
        console.log("server is running......");
       })
    }catch (error){
        console.log("Error:",error);
    }
})*/